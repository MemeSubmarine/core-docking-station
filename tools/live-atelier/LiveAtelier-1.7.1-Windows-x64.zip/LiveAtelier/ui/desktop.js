const extraRequests=new Map();
function desktopExtra(action,v=''){
    if(!native)return Promise.reject(Error('此功能需要 Windows 桌面版'));
    const request=uid();
    return new Promise((resolve,reject)=>{extraRequests.set(request,{resolve,reject});native.postMessage({id:'extra16',op:'extra16',action,v,request})});
}
native?.addEventListener('message',({data})=>{
    const reply=extraRequests.get(data.extraReply);if(!reply)return;
    extraRequests.delete(data.extraReply);data.error?reply.reject(Error(data.error)):reply.resolve(data.value);
});
// Keep the splitter outside both panels so folding removes the entire canvas.
const book=$('.book'),referencePane=$('.right');
referencePane.id='referencePane';
const rail=document.createElement('div');
rail.id='referenceRail';
rail.innerHTML='<div id="splitHandle" role="separator" tabindex="0" aria-label="调整日历与参考图占比" aria-controls="left referencePane" aria-valuemin="15" aria-valuemax="85" title="拖动调整占比"></div><button id="foldRefs" type="button" aria-controls="referencePane"></button>';
referencePane.before(rail);
const handle=$('#splitHandle'),fold=$('#foldRefs');
const splitAxis=()=>document.body.classList.contains('v')?'v':'h';
const clampRatio=n=>Math.max(15,Math.min(85,n));
function savedRatio(axis){
    const n=prefs.splitRatios?.[axis];
    return Number.isFinite(n)?clampRatio(n):(axis==='v'?63:48);
}
function paintSplit(ratio){
    book.style.setProperty('--primary-fr',ratio+'fr');
    book.style.setProperty('--reference-fr',(100-ratio)+'fr');
    handle.setAttribute('aria-valuenow',String(Math.round(ratio)));
    handle.setAttribute('aria-valuetext','主面板 '+Math.round(ratio)+'%');
}
let splitDrag=null;
function syncSplit(){
    const axis=splitAxis(),closed=view==='calendar'&&!!prefs.foldCalendar;
    if(splitDrag&&(splitDrag.axis!==axis||closed))endSplit(false);
    document.body.classList.toggle('refsFolded',closed);
    referencePane.hidden=false;$('#left').hidden=closed;rail.hidden=closed;
    openCalendar.hidden=!closed;fold.hidden=view!=='calendar';
    handle.hidden=closed;
    fold.textContent='收起日历';
    fold.setAttribute('aria-expanded',String(!closed));
    handle.setAttribute('aria-orientation',axis==='v'?'horizontal':'vertical');
    paintSplit(splitDrag?splitDrag.value:savedRatio(axis));
}
function storeRatio(axis,value){
    prefs.splitRatios={...prefs.splitRatios,[axis]:value};savePrefs()
}
function endSplit(commit){
    if(!splitDrag)return;
    const d=splitDrag;splitDrag=null;rail.classList.remove('dragging');
    if(handle.hasPointerCapture(d.id))handle.releasePointerCapture(d.id);
    if(commit)storeRatio(d.axis,d.value);
    paintSplit(savedRatio(splitAxis()));
}
const openCalendar=document.createElement('button');openCalendar.id='openCalendar';openCalendar.textContent='展开日历';referencePane.append(openCalendar);
openCalendar.onclick=fold.onclick=()=>{prefs.foldCalendar=!prefs.foldCalendar;savePrefs();syncSplit()};
handle.onpointerdown=e=>{
    if(e.button!==0||splitDrag||handle.hidden)return;
    const axis=splitAxis(),vertical=axis==='v',span=vertical?book.clientHeight-rail.offsetHeight:book.clientWidth-rail.offsetWidth;
    if(span<=0)return;
    const ratio=savedRatio(axis);
    splitDrag={id:e.pointerId,axis,span,start:vertical?e.clientY:e.clientX,ratio,value:ratio};
    handle.setPointerCapture(e.pointerId);rail.classList.add('dragging');e.preventDefault();
};
handle.onpointermove=e=>{
    const d=splitDrag;if(!d||d.id!==e.pointerId)return;
    const coordinate=d.axis==='v'?e.clientY:e.clientX;
    d.value=clampRatio(d.ratio+(coordinate-d.start)*100/d.span);paintSplit(d.value);
};
handle.onpointerup=e=>{if(splitDrag?.id===e.pointerId){handle.onpointermove(e);endSplit(true)}};
handle.onpointercancel=handle.onlostpointercapture=e=>{if(splitDrag?.id===e.pointerId)endSplit(false)};
handle.onkeydown=e=>{
    const axis=splitAxis(),keys=axis==='v'?['ArrowUp','ArrowDown']:['ArrowLeft','ArrowRight'];
    if(!keys.includes(e.key))return;
    e.preventDefault();const value=clampRatio(savedRatio(axis)+(e.key===keys[0]?-2:2));storeRatio(axis,value);paintSplit(value);
};
const orientDesk=drawLayout;
drawLayout=function(){orientDesk();syncSplit()};
window.onresize=drawLayout;
syncSplit();
const existingSettings=settings;
settings=function(){
    existingSettings();
    $('#left').insertAdjacentHTML('beforeend','<section class="module"><h2>数据备份</h2><p>包含日历、订单、工时、设置及图集文件。备份或恢复时会保存工时并重启工作台。</p><div class="tools"><button id="backupOut">导出数据</button><button id="backupIn">导入数据</button></div></section><section class="module"><h2>快捷键</h2><label><span><input id="globalKeys" type="checkbox"> 启用全局快捷键</span></label><p>参考浮窗穿透后，按此组合键恢复操作。</p><div class="keyFields"><select aria-label="修饰键" id="keyMod"><option value="3">Ctrl + Alt</option><option value="6">Ctrl + Shift</option><option value="5">Alt + Shift</option></select><select aria-label="功能键" id="keyCode"></select><button id="applyKey">保存快捷键</button></div></section>');
    const box=$('#globalKeys'),mod=$('#keyMod'),key=$('#keyCode'),apply=$('#applyKey');
    for(let i=1;i<=12;i++)key.add(new Option('F'+i,String(111+i)));
    function sync(value){box.checked=value!=='off';[mod.value,key.value]=(box.checked?value:(prefs.overlayCombo||'3,119')).split(',');mod.disabled=key.disabled=!box.checked}
    sync(prefs.overlayEnabled===false?'off':prefs.overlayCombo||'3,119');
    desktopExtra('keyGet').then(sync).catch(e=>say(e.message));
    async function save(){
        const combo=mod.value+','+key.value;
        try{await desktopExtra('keySet',box.checked?combo:'off');prefs.overlayEnabled=box.checked;prefs.overlayCombo=combo;savePrefs();sync(box.checked?combo:'off');say('快捷键已保存')}
        catch(e){say(e.message);desktopExtra('keyGet').then(sync).catch(()=>{})}
    }
    box.onchange=save;apply.onclick=save;
    async function backup(mode){
        if(mode==='import'&&!await confirmAction('恢复备份？','导入会用备份替换本机当前数据和图集。建议先导出当前数据。','选择备份'))return;
        try{if(await desktopExtra(mode)==='restart')native.postMessage({id:'orbBackupExit',op:'orbBackupExit',v:''})}catch(e){say(e.message)}
    }
    $('#backupOut').onclick=()=>backup('export');$('#backupIn').onclick=()=>backup('import');
};
const defaultBoardKeys={select:'Ctrl+A',arrange:'Ctrl+P',remove:'Delete',clear:'Escape',fit:'F'};
function boardKeys(){return {...defaultBoardKeys,...prefs.boardKeys}}
function keyChord(e){
    const k=e.key.length===1?e.key.toUpperCase():e.key;
    return [e.ctrlKey&&'Ctrl',e.altKey&&'Alt',e.shiftKey&&'Shift',k].filter(Boolean).join('+')
}
const shortcutSettings=settings;
settings=function(){
    shortcutSettings();
    const fields=document.createElement('div');
    fields.className='keyFields';$('#applyKey').parentElement.after(fields);
    for(const [id,label] of Object.entries({select:'全选参考图',arrange:'紧凑排列',remove:'移除选图',clear:'取消选择',fit:'适应画布'})){
        const box=document.createElement('label'),input=document.createElement('input');box.textContent=label;input.readOnly=true;input.value=boardKeys()[id];input.title='点此后按下新快捷键';box.append(input);fields.append(box);
        input.onkeydown=e=>{
            if(e.key==='Tab')return;
            e.preventDefault();e.stopPropagation();
            if(e.metaKey||!/^(?:[a-z0-9]|F(?:[1-9]|1[0-2])|Delete|Escape|Backspace)$/i.test(e.key))return;
            const combo=keyChord(e),bindings=boardKeys();
            if(Object.entries(bindings).some(([other,key])=>other!==id&&key===combo)){say('这个快捷键已经用于参考板的其他操作');return}
            bindings[id]=combo;prefs.boardKeys=bindings;savePrefs();input.value=combo;say('参考板快捷键已保存')
        }
    }
};
