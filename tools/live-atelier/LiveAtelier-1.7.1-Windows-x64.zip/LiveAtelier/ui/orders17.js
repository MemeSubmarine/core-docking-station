window.orbGesture=function(finish){
    if(!work.active)return false;
    if(finish){holdFocus();recordUntil(Date.now());work.active=null;persistWork();render()}
    else if(work.active.mode==='draw')pause('悬浮球暂停');else resume();
    clockPaint();return true
};
const sourceDefaults=['米画师','画加','工坊','闲鱼','QQ','微信','临界'];
function choices(name,options,selected){
    return '<div class="choices">'+[...new Set([...options,...selected])].map(t=>'<label><input type="checkbox" name="'+name+'" value="'+esc(t)+'" '+(selected.includes(t)?'checked':'')+'><span>'+esc(t)+'</span></label>').join('')+'</div>'
}
function templateCards(templates){
    return '<div class="templates">'+templates.map(t=>'<button type="button" data-template="'+esc(t.id)+'">'+(t.cover?'<img src="'+esc(t.cover)+'" alt="">':'')+'<span>'+esc(t.title)+' · ¥'+Number(t.fee||0)+' · '+esc(t.fixed?.replace('T',' ')||t.days+'天')+'</span></button>').join('')+'</div>'
}
function templatePanel(title,empty){
    const panel=document.createElement('section'),toggle=document.createElement('button'),content=document.createElement('div');
    toggle.type='button';toggle.textContent=title;toggle.className='templateButton';content.hidden=true;
    toggle.setAttribute('aria-expanded','false');
    const templates=list('template');content.innerHTML=templates.length?templateCards(templates):'<p>'+esc(empty)+'</p>';
    toggle.onclick=()=>{content.hidden=!content.hidden;toggle.setAttribute('aria-expanded',String(!content.hidden))};
    panel.append(toggle,content);return panel
}
function templateEditor(t){
    const d=document.createElement('dialog');d.className='templateEditor';document.body.append(d);
    d.innerHTML='<h2>业务模板</h2><form><label>模板名称<input required name="name"></label><label>封面 · 可用 Win+Shift+S 截图后按 Ctrl+V<input type="file" accept="image/*" name="cover"></label><img alt="" style="max-width:160px;max-height:110px"><label>约定稿酬<input name="fee" type="number" min="0" step=".01"></label><label>业务来源（逗号分隔）<input name="sources"></label><label>业务标签（逗号分隔）<input name="tags"></label><label>截稿规则<select name="rule"><option value="days">接单后若干天</option><option value="fixed">统一截稿日期</option></select></label><label>工期（天）<input type="number" name="days" min="0" max="3650"></label><label>交稿时间<input name="time" type="time"></label><label>固定日期<input name="fixed" type="datetime-local"></label><button type="button">取消</button> <button>保存模板</button></form>';
    const f=d.querySelector('form'),el=f.elements;
    for(const [k,v] of Object.entries({name:t.title,fee:t.fee||0,sources:(t.sources||[]).join('、'),tags:(t.tags||[]).join('、'),days:t.days??7,time:t.time||'18:00',fixed:t.fixed||'',rule:t.fixed?'fixed':'days'}))el[k].value=v;
    function rule(){const fixed=el.rule.value==='fixed';for(const k of ['days','time','fixed']){el[k].disabled=k==='fixed'?!fixed:fixed;el[k].required=!el[k].disabled;el[k].parentElement.hidden=el[k].disabled}}
    el.rule.onchange=rule;rule();let cover=t.cover||'',pendingCover=Promise.resolve();
    const img=d.querySelector('img');if(cover)img.src=cover;
    img.title='拖动选区裁切封面';img.draggable=false;img.style.touchAction='none';img.style.cursor='crosshair';let cropStart;
    const point=e=>{const r=img.getBoundingClientRect();return [Math.max(0,Math.min(1,(e.clientX-r.left)/r.width)),Math.max(0,Math.min(1,(e.clientY-r.top)/r.height))]};
    img.onpointerdown=e=>{if(e.button!==0)return;cropStart=point(e);img.setPointerCapture(e.pointerId)};
    img.onpointercancel=()=>cropStart=null;
    img.onpointerup=e=>{if(!cropStart)return;const end=point(e),start=cropStart;cropStart=null;const canvas=document.createElement('canvas');
        canvas.width=Math.round(Math.abs(start[0]-end[0])*img.naturalWidth);canvas.height=Math.round(Math.abs(start[1]-end[1])*img.naturalHeight);if(canvas.width<8||canvas.height<8)return;
        canvas.getContext('2d').drawImage(img,Math.min(start[0],end[0])*img.naturalWidth,Math.min(start[1],end[1])*img.naturalHeight,canvas.width,canvas.height,0,0,canvas.width,canvas.height);
        cover=img.src=canvas.toDataURL('image/png')};
    function load(file){if(file)pendingCover=resize(file,600).then(value=>{cover=img.src=value})}
    el.cover.onchange=()=>load(el.cover.files[0]);d.onpaste=e=>{const file=e.clipboardData.files[0];if(file){e.preventDefault();e.stopPropagation();load(file)}};
    d.querySelector('button').onclick=()=>d.close();d.onclose=()=>d.remove();d.showModal();
    f.onsubmit=async e=>{e.preventDefault();await pendingCover;const split=k=>el[k].value.split(/[,，、]/).map(s=>s.trim()).filter(Boolean);
        await change({...t,id:t.id||uid(),type:'template',title:el.name.value.trim(),fee:+el.fee.value,sources:split('sources'),tags:split('tags'),cover,days:+el.days.value,time:el.time.value,fixed:el.fixed.disabled?'':el.fixed.value});d.close();say('模板已保存')};
}
const legacyForm17=form;
form=function(type,i={}){
    legacyForm17(type,i);if(type!=='order')return;
    const f=modal.querySelector('form'),el=f.elements;
    el.paid?.parentElement.remove();
    const sources=[...sourceDefaults,...list('order').flatMap(o=>o.sources||[])];
    const tagRow=f.querySelector('[name=tag]').closest('.choices');
    tagRow.previousElementSibling.insertAdjacentHTML('beforebegin','<label>业务来源</label>'+choices('source',sources,i.sources||[])+'<label>新增来源<input name="extraSource"></label>');
    const picker=templatePanel('按照业务模板添加','先填写业务信息，再点「另存为业务模板」。');f.prepend(picker);
    picker.onclick=e=>{const id=e.target.closest('[data-template]')?.dataset.template,t=list('template').find(x=>x.id===id);if(!t)return;
        if(!el.title.value)el.title.value=t.title;el.fee.value=t.fee||0;el.pin.value=t.pin||'Pin';f.dataset.templatePin=t.pic||'';el.body.value=t.body||'';
        for(const [name,key,extra] of [['source','sources','extraSource'],['tag','tags','extraTags']]){const boxes=[...f.querySelectorAll('[name='+name+']')];boxes.forEach(b=>b.checked=(t[key]||[]).includes(b.value));el[extra].value=(t[key]||[]).filter(v=>!boxes.some(b=>b.value===v)).join('、')}
        const dt=new Date();dt.setDate(dt.getDate()+t.days);if(view!=='day'||t.fixed)el.due.value=t.fixed||date(dt)+'T'+t.time;el.period.value='';el.period.onchange();picker.firstChild.click()};
    const save=document.createElement('button');save.type='button';save.textContent='另存为业务模板';f.querySelector('.primary').before(save);
    save.onclick=async()=>{const data=new FormData(f),v=orderValues(data,i);templateEditor({title:el.title.value,body:el.body.value,fee:v.fee,sources:v.sources,tags:v.tags,pin:el.pin.value,pic:el.custom.files[0]?await resize(el.custom.files[0],64):f.dataset.templatePin??i.pic,time:el.due.value.slice(11)})};
};
attachProof=async function(file){
    if(!file)return;const seq=++ocrSerial,label=$('#ocrResult'),f=label.closest('form');
    try{const image=await bitmapFrame(file);if(seq!==ocrSerial)return;proof=image;label.textContent='识别中…';
        const result=JSON.parse(await host('ocr',image));if(seq!==ocrSerial||!label.isConnected)return;
        label.innerHTML='<select aria-label="填写字段"><option>订单名称</option><option>截稿时间</option></select><div style="position:relative"><img style="width:100%;height:auto;display:block" alt="约稿截图"></div>';
        const area=label.lastChild;area.firstChild.src=image;
        for(const line of result){const b=document.createElement('button');b.type='button';b.title=line.text;b.setAttribute('aria-label',line.text);
            Object.assign(b.style,{position:'absolute',left:line.x*100+'%',top:line.y*100+'%',width:line.w*100+'%',height:line.h*100+'%',minHeight:'0',padding:'0',background:'#36825e16',border:'1px solid #39886288'});area.append(b);
            b.onclick=()=>{if(label.firstChild.selectedIndex===0){f.elements.title.value=line.text;label.firstChild.selectedIndex=1}else{const v=parseDateText(line.text.replace(/[.．]/g,'/'));if(v?.due){f.elements.period.value='';f.elements.due.disabled=false;f.elements.due.value=v.due}else say('这段没有完整日期，可手动填写')}}}
        if(!result.length)label.append('未识别到文字，可手动填写。');
    }catch(e){if(seq===ocrSerial)label.textContent='识别未完成，可手动填写。 '+e.message}
};
const render17=render;render=function(){
    render17();if(view!=='orders')return;
    const lib=templatePanel('业务模板库','在订单中点击「另存为业务模板」，就能把常接的业务放到这里。');$('#left .flow').before(lib);
    lib.onclick=e=>{const t=list('template').find(o=>o.id===e.target.closest('[data-template]')?.dataset.template);if(t)templateEditor(t)};
    for(const card of document.querySelectorAll('.card.order')){const o=items.find(x=>x.id===card.dataset.item);if(o)card.insertAdjacentHTML('afterbegin','<strong class="sourceTag">'+esc((o.sources||[]).join(' · '))+'</strong>');if(o?.tags?.length)card.insertAdjacentHTML('beforeend','<small>'+esc(o.tags.join(' · '))+'</small>')}
};
const countBox=$('#count'),dueList=document.createElement('div');dueList.id='dueList';dueList.hidden=true;document.body.append(dueList);
function showDeadlines(){const current=now().slice(0,7),rows=list('order').filter(o=>!o.done&&o.due.startsWith(current)).sort((a,b)=>a.due.localeCompare(b.due));
    dueList.innerHTML='<b>本月待交稿</b>'+rows.map(o=>{const h=Math.ceil((new Date(o.due)-Date.now())/3600000);return '<div>'+esc([...(o.sources||[]),o.title].join(' · '))+'　'+esc(o.period?'本月内交付':o.due.replace('T',' ')+' · '+(h<0?'已逾期':Math.floor(h/24)+'天'+h%24+'小时'))+'</div>'}).join('')+(rows.length?'':'<div>本月没有待截稿订单</div>');
    dueList.hidden=false;const r=countBox.getBoundingClientRect();dueList.style.left=Math.max(0,Math.min(r.left,innerWidth-dueList.offsetWidth))+'px';dueList.style.top=r.bottom+'px'}
let hideDue;countBox.onmouseenter=()=>{clearTimeout(hideDue);showDeadlines()};dueList.onmouseenter=()=>clearTimeout(hideDue);countBox.onmouseleave=dueList.onmouseleave=()=>hideDue=setTimeout(()=>dueList.hidden=true,130);
function placeCalendarButton(){if(openCalendar.hidden)return;openCalendar.style.top=($('#wall').offsetTop+8)+'px';openCalendar.style.bottom='auto'}
new ResizeObserver(placeCalendarButton).observe(referencePane);
fold.addEventListener('click',()=>requestAnimationFrame(placeCalendarButton));

const settingsWithoutReset=settings;
settings=function(){
    settingsWithoutReset();
    const section=document.createElement('section');section.className='module';
    section.innerHTML='<h2>计时记录</h2><button type="button" class="danger">清空计时</button>';
    $('#left').append(section);
    section.querySelector('button').onclick=async()=>{
        if(!await confirmAction('清空全部计时？','将结束当前计时，清空所有日期的个人练习和委托工时，并将番茄钟复位。账本中的工时也会归零。订单、稿酬、模板和计时设置会保留。','确认清空'))return;
        work={...work,active:null,history:[]};persistWork();
        pomo={mode:'idle',phase:'focus',end:0,remaining:0,round:0};savePomo();
        render();clockPaint();say('全部计时记录已清空');
    };
};
