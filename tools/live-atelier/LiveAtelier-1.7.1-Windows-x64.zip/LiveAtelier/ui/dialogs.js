icons.Power='<path d="M12 2v10M5 5a9 9 0 1 0 14 0"/>';
function choiceSheet(title,content,finish){
    const sheet=document.createElement('dialog');sheet.className='choiceSheet';sheet.setAttribute('aria-label',title);
    sheet.innerHTML='<div class="sheetTop"><h2>'+esc(title)+'</h2><button type="button" data-choice="cancel" aria-label="取消">'+ic('X')+'</button></div>'+content;
    document.body.append(sheet);
    const done=choice=>{const remember=sheet.querySelector('input[type=checkbox]')?.checked||false;sheet.close();sheet.remove();scheduleShape();finish(choice,remember)};
    sheet.onclick=e=>{const button=e.target.closest('[data-choice]');if(button)done(button.dataset.choice)};
    sheet.oncancel=e=>{e.preventDefault();done('cancel')};sheet.showModal();scheduleShape();return sheet
}
function confirmAction(title,description,confirmLabel='确认移除'){
    return new Promise(resolve=>choiceSheet(title,'<p>'+esc(description)+'</p><footer><button data-choice="cancel">取消</button><button data-choice="remove" class="removeAction">'+esc(confirmLabel)+'</button></footer>',choice=>resolve(choice==='remove')))
}
window.orbRequestClose=function(){
    const send=v=>native?.postMessage({id:'orbCloseAnswer',op:'orbCloseAnswer',v});
    if(['min','exit'].includes(prefs.closeAction)){send(prefs.closeAction);return true}
    choiceSheet('离开工作台？','<div class="closeOptions"><button data-choice="min"><span>'+ic('Clock3')+'</span><div><b>最小化</b><small>收进任务栏，计时继续。</small></div></button><button data-choice="exit"><span>'+ic('Power')+'</span><div><b>退出活画师</b><small>保存本次工时，结束计时。</small></div></button></div><label class="remember"><input type="checkbox"> 记住本次选择，以后不再提醒</label>',(choice,remember)=>{if(remember&&choice!=='cancel'){prefs.closeAction=choice;savePrefs()}send(choice)});return true;
};
const appearanceSettings=settings;settings=function(){
    appearanceSettings();$('#windowPrefs').insertAdjacentHTML('beforeend','<label>点击关闭按钮时<select id="closePolicy"><option value="ask">每次询问</option><option value="min">最小化并继续计时</option><option value="exit">保存并退出</option></select></label>');
    $('#closePolicy').value=prefs.closeAction||'ask';$('#closePolicy').onchange=e=>{prefs.closeAction=e.target.value;savePrefs()}
};
const orient=$('#orient');const switcher=document.createElement('div');switcher.id='layoutSwitch';switcher.setAttribute('role','group');switcher.setAttribute('aria-label','工作台布局');
orient.replaceWith(switcher);switcher.innerHTML='<button data-layout="h">横屏</button><button data-layout="v">竖屏</button>';
switcher.onclick=async e=>{const b=e.target.closest('[data-layout]');if(!b)return;if(!['calendar','day','orders','refs'].includes(view))view='calendar';await change({id:'layout',value:b.dataset.layout})};
drawLayout=function(){const v=vert();document.body.classList.toggle('v',v);for(const b of switcher.children)b.setAttribute('aria-pressed',String(b.dataset.layout===(v?'v':'h')))};
window.onresize=drawLayout;drawLayout();initDesk();
