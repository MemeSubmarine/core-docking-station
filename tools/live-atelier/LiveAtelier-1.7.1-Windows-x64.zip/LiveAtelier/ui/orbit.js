const workType=order=>order==='general'?'practice':'commission';
function holdFocus(){
    if(pomo.mode!=='run')return;pomo.remaining=pomoLeft();pomo.mode='pause';savePomo()
}
function continueFocus(){
    if(pomo.mode==='run')return;
    const remaining=pomo.mode==='pause'?pomo.remaining:pomoDuration();
    pomo.end=Date.now()+remaining;pomo.mode='run';savePomo()
}
startFocusTogether=continueFocus;
const resumeWork=resume,pauseWork=pause;
resume=function(){continueFocus();resumeWork()};
pause=function(reason,t){holdFocus();pauseWork(reason,t)};
function switchWork(order){
    if(!order)return;unlockSound();
    const a=work.active;
    if(a&&a.order===order){if(a.mode==='draw')pause('手动暂停');else resume();return}
    if(a?.mode==='draw')recordUntil(Date.now());
    work.active={order,sessionMs:0};resume()
}
function chooseCommission(){
    const orders=list('order').filter(i=>!i.done);if(!orders.length){show('委托计时','<p>先建立一个委托，就能把绘画工时记到这张订单。</p>'+action('createCommission','新建委托'));return}
    show('工时记入哪项委托？','<form id="chooseJob"><label>委托订单<select name="job">'+orders.map(i=>'<option value="'+esc(i.id)+'" '+(i.id===work.active?.order?'selected':'')+'>'+esc(i.title)+'</option>').join('')+'</select></label><button>开始计时</button></form>');
    $('#chooseJob').onsubmit=e=>{e.preventDefault();const id=e.target.elements.job.value;modal.close();switchWork(id)}
}
function dailyTimes(t=Date.now()){
    const dayStart=new Date(t);dayStart.setHours(0,0,0,0);
    const sum={practice:0,commission:0};const add=(o,s,e)=>sum[workType(o)]+=Math.max(0,Math.min(t,e)-Math.max(+dayStart,s));
    for(const h of work.history)add(h.order,h.start,h.end);
    if(work.active?.mode==='draw')add(work.active.order,work.active.start,t);return sum
}
const paintTimes=clockPaint;
clockPaint=function(){
    paintTimes();const t=dailyTimes();for(const k of ['practice','commission']){const el=$('#elapsed-'+k);if(el)el.textContent=span(t[k])}
    if(native){const active=work.active,runs=active?.mode==='draw',kind=active?workType(active.order):'practice';
        native.postMessage({id:'orb',op:'orb',v:[runs?'1':'0',kind,span(t[kind]),duration(Math.ceil(pomoLeft()/1000)*1000),prefs.highlight||'#318361'].join('|')})}
};
const previousPhase=updatePomodoro;
updatePomodoro=function(){
    const finishingRest=pomo.mode==='run'&&pomo.phase!=='focus'&&Date.now()>=pomo.end;previousPhase();
    if(finishingRest&&work.active?.mode==='draw'){continueFocus();if(view==='time')render()}
};
const timerView=timePage;
timePage=function(){
    timerView();const first=$('.timerGrid .drawing'),a=work.active;
    for(const [k,title] of [['practice','个人练习'],['commission','委托工时']]){
        const match=a&&workType(a.order)===k,running=match&&a.mode==='draw',label=match?(running?'暂停':'继续'):'开始';
        const el=document.createElement('section');el.className='module orbitCard';el.innerHTML='<header><h2>'+title+'</h2><span>'+ (running?'记录中':match?'已暂停':'今日累计')+'</span></header><div class="orbitDial '+(running?'running':'')+'"><i></i><strong id="elapsed-'+k+'"></strong></div><div class="actions">'+action(k,label+title)+(match?button('stop','结束记录'):'')+(match&&a.reason==='电脑空闲'&&a.mode==='pause'?button('credit','补记空闲并继续'):'')+'</div>'+(k==='commission'&&match?'<p>'+esc(albumTitle(a.order))+' '+action('chooseJob','切换委托')+'</p>':'');first.before(el)
    }
    first.remove();$('.tomato .pomoDial').classList.add('orbitDial');$('.tomato .pomoDial').classList.toggle('running',pomo.mode==='run');$('.tomato .pomoDial').append(document.createElement('i'));
    if(a?.mode==='draw'){for(const b of document.querySelectorAll('[data-cmd=pomoToggle],[data-cmd=pomoReset]')){b.disabled=true;b.title='与当前工时同步，暂停工时可单独调整'}}
    clockPaint()
};
document.addEventListener('click',e=>{
    const b=e.target.closest('button');if(!b)return;
    if(b.dataset.do==='stop')holdFocus();
    const cmd=b.dataset.cmd;if(cmd==='practice')switchWork('general');if(cmd==='commission'){if(work.active&&work.active.order!=='general')switchWork(work.active.order);else chooseCommission()}
    if(cmd==='chooseJob')chooseCommission();if(cmd==='createCommission'){modal.close();form('order')}
},true);
window.orbOpen=function(page){if(['calendar','refs','time','settings','orders','ledger','gift','links'].includes(page)){view=page;render()}};
if(work.active?.mode==='pause')holdFocus();
window.orbBeforeExit=function(){if(work.active?.mode==='draw')pause('关闭软件');else holdFocus()};
const mini=document.createElement('button');mini.textContent='小表盘';mini.title='收起为悬浮小表盘';mini.onclick=()=>native?.postMessage({id:'orbMini',op:'orbMini',v:''});$('#help').before(mini);

