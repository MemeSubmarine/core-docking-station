const requests=new Map();
function shell(op,fields={},reply=false){
    const request=reply?uid():'';
    const packet={id:'shell',op:'shell',v:'',shell:op,request,...fields};
    if(!reply){native?.postMessage(packet);return}
    return new Promise((resolve,reject)=>{requests.set(request,{resolve,reject});native.postMessage(packet)});
}
native?.addEventListener('message',({data})=>{
    const p=requests.get(data.shellReply);if(!p)return;
    requests.delete(data.shellReply);data.error?p.reject(Error(data.error)):p.resolve(data.value);
});
const originalHost=host;
host=function(op,v='',extra={}){
    if(op==='store'||op==='folder'){
        const gift=!!document.querySelector('#giftForm')&&modal.open;
        return shell(op==='store'?'file':'folder',{album:extra.album,kind:gift?'gift':'ref',group:'参考图',name:extra.name||'粘贴图片.png',data:v},true);
    }
    return originalHost(op,v,extra);
};
const boardPrefs=read('boardViews',{}),positions=read('boardPositions',{});
drawWall=function(){
    let toolbar=$('.right .tools');
    if(!toolbar){toolbar=document.createElement('div');toolbar.className='tools';$('.right .head').after(toolbar)}
    toolbar.innerHTML='<select id="album" aria-label="委托图集">'+['general',...list('order').map(i=>i.id)].map(k=>'<option value="'+esc(k)+'" '+(activeAlbum===k?'selected':'')+'>'+esc(albumTitle(k))+'</option>').join('')+'</select>'+button('folder','文件夹')+button('cam','摄像头')+button('start',work.active?'查看计时':'开始画画');
    $('#album').onchange=e=>{selectAlbum(e.target.value);render()};
    toolbar.insertAdjacentHTML('beforeend','<button id="fit">归位视图</button>');
    for(const k of albums.filter(k=>k!==activeAlbum)){
        const b=document.createElement('button');b.dataset.hide=k;b.textContent='收起 '+albumTitle(k);toolbar.append(b);
    }
    const wall=$('#wall'),refs=list('ref').filter(i=>albums.includes(i.album||'general')).sort((a,b)=>a.time-b.time);
    wall.innerHTML='<div class="plane"></div>'+(refs.length?'':'<div class="dropHint">'+ic('Images')+'<strong>拖入参考图</strong><small>或粘贴图片 · Ctrl + V</small></div>');
    const plane=wall.firstElementChild, vp=boardPrefs[activeAlbum]||{x:12,y:12,z:1};
    function paint(){plane.style.transform='translate('+vp.x+'px,'+vp.y+'px) scale('+vp.z+')'}
    function persist(){boardPrefs[activeAlbum]=vp;put('boardViews',boardPrefs);put('boardPositions',positions)}
    refs.forEach((i,n)=>{
        const pos=positions[i.id]||{x:n%3*160,y:Math.floor(n/3)*160,w:142};
        const img=document.createElement('img');img.src=i.original||i.pic;img.onerror=()=>{img.onerror=null;img.src=i.pic};img.loading='lazy';img.draggable=false;img.dataset.ref=i.id;img.alt=img.title=albumTitle(i.album||'general')+' / '+i.title;
        Object.assign(img.style,{left:pos.x+'px',top:pos.y+'px',width:pos.w+'px'});plane.append(img);
        positions[i.id]=pos;img.classList.toggle('chosen',selectedRef===i.id);
        img.ondblclick=()=>{const b=document.createElement('button');b.dataset.item=i.id;document.body.append(b);b.click();b.remove()};
    });
    paint();
    $('#fit').onclick=()=>{
        const boxes=Array.from(plane.children).map(el=>({p:positions[el.dataset.ref],h:el.offsetHeight||el.offsetWidth}));
        const minX=Math.min(0,...boxes.map(b=>b.p.x)),minY=Math.min(0,...boxes.map(b=>b.p.y));
        vp.z=Math.min(1,(wall.clientWidth-24)/Math.max(1,...boxes.map(b=>b.p.x+b.p.w-minX)),(wall.clientHeight-24)/Math.max(1,...boxes.map(b=>b.p.y+b.h-minY)));
        vp.x=12-minX*vp.z;vp.y=12-minY*vp.z;paint();persist();
    };
    attachBoard(wall,plane,vp,paint,persist);
    toolbar.insertAdjacentHTML('afterbegin',action('deleteToday','清空今日')+action('deleteDate','按日期删除'));
};
let deviceOptions=[],chosen=read('cameraDevice',''),mirrored=read('cameraMirror',false);
async function devices(){
    deviceOptions=(await navigator.mediaDevices.enumerateDevices()).filter(d=>d.kind==='videoinput');
}
function syncCameraStrip(){shell('cameraStrip',{active:!!camera,labels:deviceOptions.map((d,i)=>d.label||'摄像头 '+(i+1)),index:deviceOptions.findIndex(d=>d.deviceId===chosen),mirror:mirrored})}
function setMirror(value){mirrored=!!value;put('cameraMirror',mirrored);if(frozen&&lastCameraFrame)sendCameraFrame().catch(e=>say(e.message));syncCameraStrip()}
function switchByIndex(i){if(deviceOptions[i])startDevice(deviceOptions[i].deviceId)}
let lastCameraFrame=null;
async function sendCameraFrame(){
    if(!lastCameraFrame)return;
    const src=lastCameraFrame,out=document.createElement('canvas');out.width=src.width;out.height=src.height;
    const ctx=out.getContext('2d');if(mirrored){ctx.translate(out.width,0);ctx.scale(-1,1)}ctx.drawImage(src,0,0);
    await host('frame',out.toDataURL('image/jpeg',.80));
}
async function startDevice(id){
    stopCamera();lastCameraFrame=null;const token=camGeneration;
    try{
        const media=await navigator.mediaDevices.getUserMedia({video:{...(id?{deviceId:{exact:id}}:{}),width:{ideal:960},height:{ideal:720}},audio:false});
        if(token!==camGeneration){media.getTracks().forEach(t=>t.stop());return}
        stream=media;camera=document.createElement('video');camera.muted=true;camera.srcObject=stream;await camera.play();
        chosen=media.getVideoTracks()[0].getSettings().deviceId||id;put('cameraDevice',chosen);await devices();
        if(token!==camGeneration)return;
        const raw=document.createElement('canvas');raw.width=camera.videoWidth;raw.height=camera.videoHeight;
        async function frame(){
            if(token!==camGeneration||frozen)return;
            raw.getContext('2d').drawImage(camera,0,0);lastCameraFrame=raw;await sendCameraFrame();
            if(token===camGeneration&&!frozen)frameTimer=setTimeout(()=>frame().catch(e=>{stopCamera();say(e.message)}),100);
        }
        await frame();syncCameraStrip();
    }catch(e){if(token===camGeneration){stopCamera();syncCameraStrip();say('摄像头未打开 · '+e.message)}}
}
freezeCamera=async function(){if(!camera)return;if(frozen){await startDevice(chosen);return}frozen=true;clearTimeout(frameTimer);stream?.getTracks().forEach(t=>t.stop());stream=null};
openCam=async function(){
    await devices();
    show('摄像头','<form id="cameraSetup"><label>选择摄像头<select id="sourceCam"><option value="">系统默认</option>'+deviceOptions.map((d,i)=>'<option value="'+esc(d.deviceId)+'" '+(chosen&&chosen===d.deviceId?'selected':'')+'>'+esc(d.label||'摄像头 '+(i+1))+'</option>').join('')+'</select></label><label><span><input id="flipCam" type="checkbox" style="width:auto" '+(mirrored?'checked':'')+'> 水平镜像</span></label><button class="primary">打开预览</button></form>');
    $('#cameraSetup').onsubmit=e=>{e.preventDefault();setMirror($('#flipCam').checked);const id=$('#sourceCam').value;modal.close();startDevice(id)};
};
const initialRender=render;render=function(){initialRender();$('.tabs').append($('.tabs [data-do="gift"]'));scheduleShape()};
let shapeFrame=0,lastShape='';
function updateShape(){
    // The workspace uses the entire native client rectangle.
}
function scheduleShape(){cancelAnimationFrame(shapeFrame);shapeFrame=requestAnimationFrame(updateShape)}
$('.top strong').innerHTML='<img src="icon.png" alt=""> 画师工作台';
$('.top').insertAdjacentHTML('beforeend','<button id="help" title="使用教程">?</button><button id="min" title="最小化">−</button><button id="max" title="最大化或还原">□</button><button id="close" title="关闭">×</button>');
const grip=$('.top');let moving=false,moveBusy=false;
grip.onpointerdown=e=>{if(e.button!==0||e.target.closest('button'))return;e.preventDefault();grip.setPointerCapture(e.pointerId);moving=true;shell('beginDrag',{x:e.clientX,y:e.clientY})};
window.addEventListener('pointermove',async e=>{if(!moving||moveBusy)return;moveBusy=true;try{await shell('drag',{x:e.clientX,y:e.clientY,width:innerWidth},true)}finally{moveBusy=false}},true);
function endMove(){if(moving)shell('endDrag');moving=false}
for(const event of ['pointerup','pointercancel','blur'])window.addEventListener(event,endMove,true);
grip.onlostpointercapture=endMove;
for(const id of ['min','max','close'])$('#'+id).onclick=()=>shell(id);
document.body.insertAdjacentHTML('beforeend','<button id="sizeGrip" title="拖动调整窗口大小" aria-label="拖动调整窗口大小">◢</button>');
$('#sizeGrip').onpointerdown=e=>{e.preventDefault();shell('resize')};
new ResizeObserver(scheduleShape).observe(document.body);
new MutationObserver(scheduleShape).observe(document.querySelector('.tabs'),{childList:true});
new MutationObserver(scheduleShape).observe(modal,{attributes:true,attributeFilter:['open']});
window.addEventListener('resize',scheduleShape);
scheduleShape();
