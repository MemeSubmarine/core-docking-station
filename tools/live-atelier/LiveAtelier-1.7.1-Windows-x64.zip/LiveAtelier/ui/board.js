const boardSelection=new Set();
function attachBoard(wall,plane,vp,paint,persist){
    const images=[...plane.children],ids=images.map(i=>i.dataset.ref);
    let drag=null;
    wall.tabIndex=0; wall.setAttribute('aria-label','参考板：左键框选，中键平移，滚轮缩放画布，Ctrl + Alt 拖动缩放选图');
    for(const id of boardSelection)if(!ids.includes(id))boardSelection.delete(id);
    const active=()=>images.filter(i=>boardSelection.has(i.dataset.ref));
    const pos=i=>positions[i.dataset.ref],height=i=>i.naturalWidth?pos(i).w*i.naturalHeight/i.naturalWidth:i.offsetHeight||pos(i).w;
    function refresh(){
        for(const img of images){const p=pos(img);img.classList.toggle('chosen',boardSelection.has(img.dataset.ref));
            Object.assign(img.style,{left:p.x+'px',top:p.y+'px',width:p.w+'px',transform:'scale('+(p.flipX?-1:1)+','+(p.flipY?-1:1)+')',zIndex:p.layer||0})}
    }
    refresh();
    const point=e=>{const r=wall.getBoundingClientRect();return {x:(e.clientX-r.left-vp.x)/vp.z,y:(e.clientY-r.top-vp.y)/vp.z}};
    function single(img){boardSelection.clear();boardSelection.add(img.dataset.ref);refresh()}
    function bounds(set){return {x:Math.min(...set.map(i=>pos(i).x)),y:Math.min(...set.map(i=>pos(i).y)),r:Math.max(...set.map(i=>pos(i).x+pos(i).w)),b:Math.max(...set.map(i=>pos(i).y+height(i)))}}
    function scale(set,k,center){
        if(!set.length)return;k=Math.min(Math.min(...set.map(i=>12000/pos(i).w)),Math.max(Math.max(...set.map(i=>12/pos(i).w)),k));
        for(const img of set){const p=pos(img);p.x=center.x+(p.x-center.x)*k;p.y=center.y+(p.y-center.y)*k;p.w*=k}refresh()
    }
    function fit(set){if(!set.length)return;const box=bounds(set);vp.z=Math.max(.015,Math.min(6,(wall.clientWidth-24)/Math.max(1,box.r-box.x),(wall.clientHeight-24)/Math.max(1,box.b-box.y)));vp.x=(wall.clientWidth-(box.r-box.x)*vp.z)/2-box.x*vp.z;vp.y=(wall.clientHeight-(box.b-box.y)*vp.z)/2-box.y*vp.z;paint();persist()}
    $('#fit').onclick=()=>fit(images);
    function arrange(kind){
        const set=active().length?active():images;if(!set.length)return;
        const box=bounds(set);
        if(['optimal','row','column'].includes(kind)){
            const area=set.reduce((s,i)=>s+(pos(i).w+8)*(height(i)+8),0);
            const width=Math.max(...set.map(i=>pos(i).w),Math.sqrt(area));
            const ordered=kind==='optimal'?[...set].sort((a,b)=>height(b)-height(a)):set;
            let x=box.x,y=box.y,row=0;
            for(const img of ordered){const p=pos(img);if(kind==='optimal'&&x>box.x&&x+p.w>box.x+width){x=box.x;y+=row+8;row=0}p.x=x;p.y=y;if(kind==='column')y+=height(img)+8;else x+=p.w+8;row=Math.max(row,height(img))}
        }else for(const img of set){const p=pos(img);if(kind==='left')p.x=box.x;if(kind==='right')p.x=box.r-p.w;if(kind==='top')p.y=box.y;if(kind==='bottom')p.y=box.b-height(img);if(kind==='width')p.w=pos(set[0]).w;if(kind==='flipX'||kind==='flipY')p[kind]=!p[kind]}
        refresh();persist();if(!active().length)fit(set)
    }
    function remove(){const rows=items.filter(i=>boardSelection.has(i.id)&&i.type==='ref');if(rows.length)confirmRefs(rows,'选中的参考图')}
    function menu(e){
        e.preventDefault();$('#boardMenu')?.remove();const img=e.target.closest('[data-ref]');if(img&&!boardSelection.has(img.dataset.ref))single(img);
        const m=document.createElement('div');m.id='boardMenu';m.setAttribute('role','menu');document.body.append(m);
        const add=(label,fn,parent=m)=>{const b=document.createElement('button');b.textContent=label;b.onclick=()=>{m.remove();fn()};parent.append(b)};
        const group=(label,commands)=>{const d=document.createElement('details'),h=document.createElement('summary');h.textContent=label;d.append(h);m.append(d);commands.forEach(([s,k])=>add(s,()=>arrange(k),d))};
        const label=document.createElement('small');label.textContent=active().length?'选中 '+active().length+' 张':'整个参考板';m.append(label);
        group('排列整理',[['紧凑排列　'+boardKeys().arrange,'optimal'],['水平排列','row'],['垂直排列','column']]);m.querySelector('details').open=true;
        group('对齐与尺寸',[['左边对齐','left'],['右边对齐','right'],['顶边对齐','top'],['底边对齐','bottom'],['统一宽度','width']]);
        if(active().length){group('翻转',[['水平翻转','flipX'],['垂直翻转','flipY']]);add('聚焦选中图',()=>fit(active()));add('删除选中图片',remove)}
        add('显示全部图片',()=>fit(images));add('全选',()=>{ids.forEach(id=>boardSelection.add(id));refresh()});
        m.style.left=Math.max(0,Math.min(e.clientX,innerWidth-m.offsetWidth-5))+'px';m.style.top=Math.max(0,Math.min(e.clientY,innerHeight-m.offsetHeight-5))+'px';m.querySelector('summary').focus()
    }
    wall.oncontextmenu=menu;
    wall.onpointerdown=e=>{
        if(e.button>1)return;wall.focus({preventScroll:true});const img=e.target.closest('[data-ref]'),p=point(e);
        const mode=e.button===1||e.altKey&&!e.ctrlKey?'pan':e.ctrlKey&&e.altKey&&img?'scale':img?'move':'box';
        const before=new Set(boardSelection);
        if(img&&mode!=='pan'){
            if((e.ctrlKey||e.shiftKey)&&mode==='move'){if(before.has(img.dataset.ref))boardSelection.delete(img.dataset.ref);else boardSelection.add(img.dataset.ref)}
            else if(!before.has(img.dataset.ref))single(img);
            if(boardSelection.has(img.dataset.ref))pos(img).layer=Math.max(0,...images.map(i=>pos(i).layer||0))+1;
        }else if(mode==='box'&&!e.shiftKey&&!e.ctrlKey)boardSelection.clear();
        refresh();drag={mode,p,last:p,sx:e.clientX,sy:e.clientY,vx:vp.x,vy:vp.y,before,group:active().map(i=>[i,{...pos(i)}]),img};
        if(mode==='box'){drag.box=document.createElement('div');drag.box.className='marquee';plane.append(drag.box)}
        wall.setPointerCapture(e.pointerId);e.preventDefault()
    };
    wall.onpointermove=e=>{
        if(!drag)return;const d=drag,p=point(e),dx=p.x-d.p.x,dy=p.y-d.p.y;
        if(d.mode==='pan'){vp.x=d.vx+e.clientX-d.sx;vp.y=d.vy+e.clientY-d.sy;paint();return}
        if(d.mode==='move'){for(const [img,start] of d.group){pos(img).x=start.x+dx;pos(img).y=start.y+dy}refresh()}
        if(d.mode==='scale')scale(active(),Math.exp((p.x-d.last.x)*vp.z/160),d.p);
        if(d.mode==='box'){const x=Math.min(d.p.x,p.x),y=Math.min(d.p.y,p.y),r=Math.max(d.p.x,p.x),b=Math.max(d.p.y,p.y);Object.assign(d.box.style,{left:x+'px',top:y+'px',width:r-x+'px',height:b-y+'px'});
            boardSelection.clear();for(const img of images){const q=pos(img),id=img.dataset.ref,hit=q.x<r&&q.x+q.w>x&&q.y<b&&q.y+height(img)>y;if(e.ctrlKey?hit!==d.before.has(id):hit||(e.shiftKey&&d.before.has(id)))boardSelection.add(id)}refresh()}
        d.last=p
    };
    wall.onpointerup=e=>{if(!drag)return;const d=drag;if(d.mode==='move'&&d.group.length&&Math.hypot(e.clientX-d.sx,e.clientY-d.sy)>2){
        const anchor=d.group[0][0],p=pos(anchor),others=images.filter(i=>!boardSelection.has(i.dataset.ref));
        const dx=snapAxis(p.x,p.w,others.map(i=>[pos(i).x,pos(i).w]),9/vp.z)-p.x,dy=snapAxis(p.y,height(anchor),others.map(i=>[pos(i).y,height(i)]),9/vp.z)-p.y;
        for(const [i] of d.group){pos(i).x+=dx;pos(i).y+=dy}
    }d.box?.remove();drag=null;refresh();persist()};
    wall.onpointercancel=()=>{drag?.box?.remove();drag=null;persist()};
    wall.onwheel=e=>{e.preventDefault();const k=Math.exp(-Math.sign(e.deltaY)*.12),p=point(e),img=e.target.closest('[data-ref]');
        if((e.shiftKey||e.ctrlKey)&&img){if(!boardSelection.has(img.dataset.ref))single(img);scale(active(),k,p)}
        else{const z=Math.max(.015,Math.min(8,vp.z*k));vp.x+=p.x*(vp.z-z);vp.y+=p.y*(vp.z-z);vp.z=z;paint()}persist()};
    wall.onkeydown=e=>{const combo=keyChord(e),keys=boardKeys();if(combo===keys.select){ids.forEach(id=>boardSelection.add(id));refresh()}else if(combo===keys.arrange)arrange('optimal');else if(combo===keys.remove)remove();else if(combo===keys.clear){boardSelection.clear();refresh()}else if(combo===keys.fit)fit(active().length?active():images);else return;e.preventDefault()};
}
