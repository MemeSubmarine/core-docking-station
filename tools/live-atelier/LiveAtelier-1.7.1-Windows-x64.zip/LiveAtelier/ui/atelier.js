const action=(name,label,style='')=>'<button type="button" class="'+style+'" data-cmd="'+name+'">'+label+'</button>';
const duration=ms=>span(ms).replace(/^00:/,'');
const statusText=a=>a?.mode==='draw'?'记录中':a?'已暂停':'尚未开始';
const sectionHead=(title,subtitle='')=>'<header class="sectionHead"><h1>'+title+'</h1>'+(subtitle?'<p>'+subtitle+'</p>':'')+'</header>';
let pomo=read('independentPomodoro',{mode:'idle',phase:'focus',end:0,remaining:0});
const pomoDuration=()=>60000*phaseMinutes();
const pomoLeft=()=>pomo.mode==='run'?Math.max(0,pomo.end-Date.now()):pomo.mode==='pause'?pomo.remaining:pomoDuration();
const savePomo=()=>put('independentPomodoro',pomo);
function updatePomodoro(){
    if(pomo.mode!=='run'||Date.now()<pomo.end)return;
    const wasFocus=pomo.phase==='focus';
    pomo.phase=wasFocus?'rest':'focus';pomo.mode=wasFocus?'run':'idle';
    pomo.end=Date.now()+pomoDuration();pomo.remaining=0;savePomo();chime();
    say(wasFocus?'专注结束，可以休息了':'休息结束');if(view==='time')render();
}
function workElapsed(){
    const a=work.active;if(!a)return 0;
    return (a.sessionMs||0)+(a.mode==='draw'?Math.max(0,Date.now()-a.start):0);
}
const savePause=pause;
pause=function(reason,t=Date.now()){
    const a=work.active;if(a?.mode==='draw')a.sessionMs=(a.sessionMs||0)+Math.max(0,t-a.start);
    savePause(reason,t);
};
resume=function(){
    const a=work.active,t=Date.now();a.start=a.heartbeat=t;a.until=8640000000000000;
    a.mode='draw';a.nextWater=t+prefs.water*60000;a.nextSit=t+prefs.sit*60000;
    persistWork();lastIdle=0;render();
};
function clockPaint(){
    const elapsed=$('#elapsed');if(elapsed)elapsed.textContent=span(workElapsed());
    const face=$('#pomoFace');if(face){face.textContent=duration(Math.ceil(pomoLeft()/1000)*1000);face.parentNode.style.setProperty('--progress',(1-pomoLeft()/pomoDuration())*100+'%')}
}
const legacyTick=tick;
tick=function(){updatePomodoro();legacyTick();clockPaint()};
setupTimer=function(){
    if(work.active){view='time';render();return}
    show('开始绘画计时','<form id="drawSetup"><label>工时记入<select name="job"><option value="general">个人练习</option>'+list('order').filter(i=>!i.done).map(i=>'<option value="'+i.id+'" '+(i.id===activeAlbum?'selected':'')+'>'+esc(i.title)+'</option>').join('')+'</select></label><label>电脑空闲多少分钟后暂停<input type="number" min="0" max="1440" name="idle" value="'+prefs.idle+'"></label><small>填 0 可关闭空闲暂停。开始记录时，番茄钟也会开始专注。</small><button class="primary">开始记录工时</button></form>');
    $('#drawSetup').onsubmit=e=>{e.preventDefault();unlockSound();const f=new FormData(e.target);prefs.idle=Number(f.get('idle'));put('prefs',prefs);work.active={order:f.get('job'),sessionMs:0};view='time';modal.close();startFocusTogether();resume()};
};
function field(name,label,value,max=1440,min=0){
    return '<label class="inlineField">'+label+'<input type="number" data-pref="'+name+'" value="'+value+'" min="'+min+'" max="'+max+'" step="1"></label>';
}
timePage=function(){
    const a=work.active,water=read('water'+now(),0);
    $('#left').innerHTML=sectionHead('计时与休息')+'<div class="timerGrid"><section class="module drawing"><header><h2>绘画工时</h2><span class="state">'+statusText(a)+'</span></header><p>'+(a?esc(a.order==='general'?'个人练习':albumTitle(a.order)):'选择委托或个人练习')+'</p><strong class="digits" id="elapsed">'+span(workElapsed())+'</strong><div class="actions">'+(a?(a.mode==='draw'?button('pause','暂停工时'):button('resume','继续绘画'))+button('stop','结束记录'):button('start','开始画画'))+(a?.reason==='电脑空闲'&&a.mode==='pause'?button('credit','补记空闲并继续'):'')+'</div></section>'+
    '<section class="module tomato"><header><h2>番茄钟</h2><span class="state">'+(pomo.phase==='rest'?'休息':'专注')+'</span></header><div class="pomoDial"><b id="pomoFace"></b></div><div class="actions">'+action('pomoToggle',pomo.mode==='run'?'暂停倒计时':pomo.mode==='pause'?'继续倒计时':'开始专注','warm')+action('pomoReset','重置')+'</div><div class="twoFields">'+field('focus','专注 · 分钟',prefs.focus,240,1)+field('rest','休息 · 分钟',prefs.rest,120,1)+'</div></section>'+
    '<section class="module water"><header><h2>今日喝水</h2><b>'+water+' / '+prefs.goal+' 杯</b></header><progress max="'+prefs.goal+'" value="'+water+'"></progress><div class="actions">'+button('drink','＋ 记一杯')+button('undrink','撤销一杯')+'</div><div class="twoFields">'+field('goal','每日目标 · 杯',prefs.goal,99,1)+field('water','绘画时提醒 · 分钟',prefs.water)+'</div></section>'+
    '<section class="module"><header><h2>起身活动</h2></header>'+field('sit','绘画时提醒 · 分钟',prefs.sit)+'<p>间隔填 0 可关闭提醒。</p></section></div>';
    for(const el of document.querySelectorAll('.tomato input'))el.disabled=pomo.mode!=='idle';
    clockPaint();
};
document.addEventListener('change',e=>{
    const k=e.target.dataset.pref;if(!k)return;
    const val=e.target.valueAsNumber;if(!e.target.checkValidity()||!Number.isFinite(val)){e.target.value=prefs[k];return}
    prefs[k]=val;put('prefs',prefs);if(work.active&&['water','sit'].includes(k))work.active[k==='water'?'nextWater':'nextSit']=Date.now()+val*60000;
    if(view==='time')timePage();
});
links=function(){
    const group=(name,rows)=>'<section class="module linkGroup"><header><h2>'+name+'</h2><span>'+rows.length+'</span></header>'+rows.map(i=>'<article class="siteRow"><button data-link="'+esc(i.id)+'"><b>'+esc(i.title)+'</b><small>'+esc(i.body)+'</small><span>'+esc(i.url)+'</span></button>'+(i.type?'<button data-remove="'+i.id+'" aria-label="移除收藏">移除</button>':'')+'</article>').join('')+(!rows.length?'<p>收藏常用网站，并给每个链接写一句用途。</p>':'')+'</section>';
    $('#left').innerHTML=sectionHead('网站库')+'<div class="actions">'+button('newLink','＋ 收藏网址')+'</div><div class="linkGrid">'+group('我的收藏',list('link'))+group('内置图库',sites)+'</div>';
};
const oldLedger=ledger;
ledger=function(){
    oldLedger();const {income,ms,practice}=monthly(bookMonth);
    const next=local(bookMonth+'-01');next.setMonth(next.getMonth()+1);
    const estimate=list('order').filter(i=>!i.paid&&i.due.slice(0,7)<=date(next).slice(0,7)).reduce((s,i)=>s+(i.fee||0),0);
    const cards=[['本月约定稿酬',money(income)],['委托工时',span(ms)],['约定稿酬折算时薪',ms?money(income*3600000/ms)+'/h':'—'],['个人练习',span(practice)],['截至下月底待收',money(estimate)]];
    $('#left .info').remove();$('#left .stat').outerHTML='<div class="metrics">'+cards.map(([n,v])=>'<div><small>'+n+'</small><b>'+v+'</b></div>').join('')+'</div>';
    const table=$('.records');const container=document.createElement('div');container.className='tableScroll';table.before(container);container.append(table);
};
const baseGift=giftForm;
giftForm=function(i){
    baseGift(i);const file=$('#giftForm input[type=file]'),zone=file.parentNode;
    zone.className='imageDrop';zone.insertAdjacentHTML('beforeend','<span>拖入图片，或按 Ctrl + V</span>'+action('pasteImage','粘贴截图')+'<img class="giftPreview" hidden alt="当前作品">');
    file.onchange=()=>{const img=zone.querySelector('img');if(img.dataset.blob)URL.revokeObjectURL(img.dataset.blob);if(file.files[0]){img.src=img.dataset.blob=URL.createObjectURL(file.files[0]);img.hidden=false}};
    zone.ondragover=e=>e.preventDefault();zone.ondrop=e=>{e.preventDefault();setGiftFile(imageFiles(e.dataTransfer)[0])};
};
function imageFiles(data){
    const files=[...(data?.files||[])].filter(f=>f.type.startsWith('image/'));
    return files.length?files:[...(data?.items||[])].filter(v=>v.kind==='file'&&v.type.startsWith('image/')).map(v=>v.getAsFile()).filter(Boolean);
}
function setGiftFile(f){
    const input=$('#giftForm input[type=file]');if(!input||!f)return;
    const dt=new DataTransfer();dt.items.add(f);input.files=dt.files;input.dispatchEvent(new Event('change',{bubbles:true}));
}
async function routeImage(files){
    if(!files.length)return;
    if(modal.open&&$('#giftForm'))setGiftFile(files[0]);
    else if(modal.open&&$('#proofFile'))await attachProof(files[0]);
    else if(!modal.open&&view==='gift'){giftForm();setGiftFile(files[0])}
    else if(!modal.open)await ingest(files,'ref');
}
document.addEventListener('paste',e=>{
    if(e.target.closest?.('.templateEditor'))return;const files=imageFiles(e.clipboardData);if(!files.length||modal.open&&!$('#giftForm')&&!$('#proofFile'))return;
    e.stopImmediatePropagation();e.preventDefault();routeImage(files).catch(err=>say(err.message));
},true);
async function pasteNative(){
    const data=await shell('clipboard',{},true);const bytes=Uint8Array.from(atob(data),c=>c.charCodeAt(0));await routeImage([new File([bytes],'截图.png',{type:'image/png'})]);
}
const oldWall=drawWall;drawWall=function(){
    oldWall();$('#import').insertAdjacentHTML('beforebegin',action('pasteImage','粘贴截图'));
    const head=$('.right .head');const pastes=head.querySelectorAll('[data-cmd="pasteImage"]');for(const b of [...pastes].slice(0,-1))b.remove();
};
const openOrder=form;form=function(type,i={}){
    openOrder(type,i);if(type==='order')$('#proofFile').insertAdjacentHTML('afterend',action('pasteImage','从剪贴板读取截图'));
};
function tour(step=0){
    const frames=[
        ['把委托钉到日期上','点 18 日，查看这一天的委托。','<div class="demoMonth">'+Array.from({length:14},(_,j)=>j===10?action('tourNext','18','demoHot'):'<span>'+(8+j)+'</span>').join('')+'</div>'],
        ['打开这单的参考板','点示例委托，打开对应的参考板。',action('tourNext','<small>18 日 · 18:00 截稿</small><b>头像委托</b><span>打开参考板 →</span>','demoJob')],
        ['把截图放到板上','点「粘贴示例图」，试一次导入。','<div class="demoBoard">'+action('tourNext','＋ 粘贴示例图','demoHot')+'</div>'],
        ['自由摆放参考图','拖动默认图片换个位置，再点下一步。','<div class="demoBoard"><img draggable="false" id="demoPic" src="default.png" alt="可拖动的默认图片"></div>'],
        ['在双表盘里开始绘画','点「开始专注」，观察两个时钟。','<div class="demoClocks"><div><small>绘画工时</small><b id="demoWork">00:12</b></div><div><small>番茄钟</small><b id="demoPomo">25:00</b></div></div>'+action('tourClock','开始专注','warm')],
        ['把工作台留在画布旁','点图钉试试置顶状态。正式使用时，图钉就在主窗口顶部。',action('tourPin',ic('Pin')+' 置顶','demoPin')]
    ];
    const [title,desc,body]=frames[step];show('操作演示','<div class="tour" data-step="'+step+'"><small>演示 '+(step+1)+' / '+frames.length+'</small><h3>'+title+'</h3><p>'+desc+'</p>'+body+'<footer>'+action('tourPrev','← 上一步')+action(step===5?'tourDone':'tourNext',step===5?'完成':'下一步 →')+'</footer></div>');$('.tour [data-cmd=tourPrev]').disabled=!step;
    const pic=$('#demoPic');if(pic){pic.onpointerdown=e=>{pic.setPointerCapture(e.pointerId)};pic.onpointermove=e=>{if(!e.buttons)return;const r=pic.parentNode.getBoundingClientRect();pic.style.left=Math.max(0,Math.min(r.width-pic.offsetWidth,e.clientX-r.left-pic.offsetWidth/2))+'px';pic.style.top=Math.max(0,Math.min(r.height-pic.offsetHeight,e.clientY-r.top-pic.offsetHeight/2))+'px'};}
}
$('#help').onclick=()=>tour();$('#help').title='操作演示';
$('#help').insertAdjacentHTML('beforebegin','<button id="pinTop" title="主窗口置顶" aria-label="主窗口置顶">'+ic('Pin')+'<span>置顶</span></button>');
$('#pinTop').onclick=async()=>{try{await host('top',prefs.top?'off':'on');prefs.top=!prefs.top;put('prefs',prefs);render()}catch(e){say(e.message)}};
const originalSettings=settings;
settings=function(){
    originalSettings();const left=$('#left');
    const controls=[...left.querySelectorAll('.tools button')],goal=left.querySelector('#goal').parentElement,sound=left.querySelector('#sound').parentElement;
    const listen=left.querySelector('[data-do=listen]'),reset=left.querySelector('[data-do=resetSound]');
    left.innerHTML=sectionHead('设置')+'<div class="settingGrid"><section class="module" id="windowPrefs"><h2>窗口与外观</h2></section><section class="module" id="audioPrefs"><h2>提醒声音</h2></section><section class="module" id="waterPrefs"><h2>喝水目标</h2></section></div>';
    controls.forEach((b,i)=>{const row=document.createElement('div');row.className='settingRow';row.innerHTML='<span>'+['界面主题','主窗口置顶','开机启动'][i]+'</span>';row.append(b);$('#windowPrefs').append(row)});
    $('#audioPrefs').append(sound,listen,reset);$('#waterPrefs').append(goal);
};
const previousGifts=gifts;
gifts=function(){
    previousGifts();const left=$('#left');
    left.querySelector('.hint')?.remove();
    left.querySelector('.tools').insertAdjacentHTML('afterend',archived?'':'<div id="giftLanding" class="giftLanding">'+ic('Images')+'<div><b>收到的作品</b><small>拖入一张作品，或粘贴刚截下的画面</small></div>'+action('giftPaste','粘贴截图')+'</div>');
    const landing=$('#giftLanding');if(landing){landing.ondragover=e=>e.preventDefault();landing.ondrop=e=>{e.preventDefault();const f=imageFiles(e.dataTransfer)[0];if(f){giftForm();setGiftFile(f)}}}
    const cards=[...left.querySelectorAll('.card')];if(cards.length){const list=document.createElement('div');list.className='giftCards';cards[0].before(list);list.append(...cards)}
};
const drawOriginalLeft=drawLeft;
drawLeft=function(){
    if(view!=='refs'){drawOriginalLeft();return}
    const refs=list('ref'),keys=[...new Set(['general',...list('order').map(x=>x.id),...refs.map(x=>x.album||'general')])];
    $('#left').innerHTML=sectionHead('参考图库')+'<div class="albumList">'+keys.map(k=>{
        const arr=refs.filter(r=>(r.album||'general')===k);return '<button class="albumCard" data-selectalbum="'+esc(k)+'" aria-pressed="'+(k===activeAlbum)+'"><span class="albumCover">'+(arr.length?'<img src="'+esc(arr[0].pic)+'" alt="">':ic('Images'))+'</span><span><b>'+esc(albumTitle(k))+'</b><small>'+arr.length+' 张图片</small></span><span>→</span></button>';
    }).join('')+'</div>';
};
let tourTicker;
document.addEventListener('click',async e=>{
    const album=e.target.closest('[data-selectalbum]');if(album){selectAlbum(album.dataset.selectalbum);render();return}
    const b=e.target.closest('[data-cmd]');if(!b)return;const cmd=b.dataset.cmd;
    try{
        if(cmd==='pasteImage'||cmd==='giftPaste'){e.preventDefault();await pasteNative()}
        else if(cmd==='pomoToggle'){unlockSound();if(pomo.mode==='run'){pomo.remaining=pomoLeft();pomo.mode='pause'}else{pomo.end=Date.now()+pomoLeft();pomo.mode='run'}savePomo();render()}
        else if(cmd==='pomoReset'){pomo={mode:'idle',phase:'focus',end:0,remaining:0};savePomo();render()}
        else if(cmd==='tourNext'||cmd==='tourPrev'){clearInterval(tourTicker);tour(Number($('.tour').dataset.step)+(cmd==='tourNext'?1:-1))}
        else if(cmd==='tourDone')modal.close();
        else if(cmd==='tourPin'){b.classList.toggle('selected');b.innerHTML=ic('Pin')+(b.classList.contains('selected')?' 已置顶':' 置顶')}
        else if(cmd==='tourClock'){b.disabled=true;let s=0;const step=()=>{if(!$('#demoWork')){clearInterval(tourTicker);return}$('#demoWork').textContent=duration((12+s)*1000);$('#demoPomo').textContent=duration((1500-s)*1000);s++};step();tourTicker=setInterval(step,1000)}
    }catch(err){say(err.message)}
});
modal.addEventListener('close',()=>clearInterval(tourTicker));
const previousRender=render;render=function(){
    document.body.dataset.view=view;previousRender();
    const btn=$('#pinTop');btn.setAttribute('aria-pressed',String(!!prefs.top));btn.title=prefs.top?'取消主窗口置顶':'主窗口置顶';btn.querySelector('span').textContent=prefs.top?'已置顶':'置顶';
    const back=$('#left button[data-a=calendar]');if(back)back.innerHTML=ic('ChevronLeft')+'返回日历';
    const check=$('#left [data-do=check]');if(check){check.classList.add('checkIn');const checked=items.some(i=>i.id==='check'+(view==='day'?day:now()));check.setAttribute('aria-pressed',String(checked));check.textContent=checked?'✓ 已打卡':'✓ 画画打卡';if($('.foot'))$('.foot').append(check)}
    scheduleShape();
};
if(db)render();
