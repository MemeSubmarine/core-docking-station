Object.assign(icons,{"Handshake":"<path d=\"m11 17 2 2a1 1 0 1 0 3-3\"/><path d=\"m14 14 2.5 2.5a1 1 0 1 0 3-3l-3.88-3.88a3 3 0 0 0-4.24 0l-.88.88a1 1 0 1 1-3-3l2.81-2.81a5.79 5.79 0 0 1 7.06-.87l.47.28a2 2 0 0 0 1.42.25L21 4\"/><path d=\"m21 3 1 11h-2\"/><path d=\"M3 3 2 14l6.5 6.5a1 1 0 1 0 3-3\"/><path d=\"M3 4h8\"/>","Globe":"<circle cx=\"12\" cy=\"12\" r=\"10\"/><path d=\"M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20\"/><path d=\"M2 12h20\"/>","Settings":"<path d=\"M9.671 4.136a2.34 2.34 0 0 1 4.659 0 2.34 2.34 0 0 0 3.319 1.915 2.34 2.34 0 0 1 2.33 4.033 2.34 2.34 0 0 0 0 3.831 2.34 2.34 0 0 1-2.33 4.033 2.34 2.34 0 0 0-3.319 1.915 2.34 2.34 0 0 1-4.659 0 2.34 2.34 0 0 0-3.32-1.915 2.34 2.34 0 0 1-2.33-4.033 2.34 2.34 0 0 0 0-3.831A2.34 2.34 0 0 1 6.35 6.051a2.34 2.34 0 0 0 3.319-1.915\"/><circle cx=\"12\" cy=\"12\" r=\"3\"/>","Timer":"<line x1=\"10\" x2=\"14\" y1=\"2\" y2=\"2\"/><line x1=\"12\" x2=\"15\" y1=\"14\" y2=\"11\"/><circle cx=\"12\" cy=\"14\" r=\"8\"/>","GlassWater":"<path d=\"M5.116 4.104A1 1 0 0 1 6.11 3h11.78a1 1 0 0 1 .994 1.105L17.19 20.21A2 2 0 0 1 15.2 22H8.8a2 2 0 0 1-2-1.79z\"/><path d=\"M6 12a5 5 0 0 1 6 0 5 5 0 0 0 6 0\"/>","Volume2":"<path d=\"M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z\"/><path d=\"M16 9a5 5 0 0 1 0 6\"/><path d=\"M19.364 18.364a9 9 0 0 0 0-12.728\"/>"});
let selectedRef='';
const savePrefs=()=>put('prefs',prefs);
function snapAxis(value,size,others,tolerance){
    let best=tolerance,offset=0;
    for(const [start,length] of others){
        for(const delta of [start-value,start+length-value-size,start+length+8-value,start-8-size-value]){
            if(Math.abs(delta)<best){best=Math.abs(delta);offset=delta}
        }
    }
    return best<tolerance?value+offset:Math.round(value/8)*8;
}
function snapImage(img,plane,zoom){
    const p=positions[img.dataset.ref],others=[...plane.children].filter(x=>x!==img);
    p.x=snapAxis(p.x,p.w,others.map(x=>[positions[x.dataset.ref].x,x.offsetWidth]),9/zoom);
    p.y=snapAxis(p.y,img.offsetHeight,others.map(x=>[positions[x.dataset.ref].y,x.offsetHeight]),9/zoom);
    img.style.left=p.x+'px';img.style.top=p.y+'px';
}
function boardMenu(e,plane,wall){
    e.preventDefault();document.querySelector('#boardMenu')?.remove();
    const id=e.target.dataset.ref;
    if(id){selectedRef=id;for(const x of plane.children)x.classList.toggle('chosen',x.dataset.ref===id)}
    const menu=document.createElement('div');menu.id='boardMenu';menu.setAttribute('role','menu');
    const item=document.createElement('button');item.textContent=id?'删除这张参考图':'自动排列整理';menu.append(item);document.body.append(menu);
    menu.style.left=Math.max(0,Math.min(e.clientX,innerWidth-menu.offsetWidth))+'px';
    menu.style.top=Math.max(0,Math.min(e.clientY,innerHeight-menu.offsetHeight))+'px';item.focus();
    item.onclick=()=>{menu.remove();if(id){const ref=items.find(x=>x.id===id);if(ref)confirmRefs([ref],ref.title);return}
        const cols=Math.max(1,Math.floor((wall.clientWidth-24)/158));let y=0,rowHeight=0;
        [...plane.children].sort((a,b)=>positions[a.dataset.ref].y-positions[b.dataset.ref].y||positions[a.dataset.ref].x-positions[b.dataset.ref].x).forEach((img,n)=>{
            if(n&&n%cols===0){y+=rowHeight+12;rowHeight=0}
            const p=positions[img.dataset.ref];p.w=146;p.x=n%cols*158;p.y=y;
            Object.assign(img.style,{width:p.w+'px',left:p.x+'px',top:p.y+'px'});rowHeight=Math.max(rowHeight,img.offsetHeight||146)
        });$('#fit').click();
    };
}
document.addEventListener('pointerdown',e=>{if(!e.target.closest('#boardMenu'))$('#boardMenu')?.remove()},true);
document.addEventListener('keydown',e=>{if(e.key==='Escape')$('#boardMenu')?.remove()});
const addedOn=i=>i.addedDay||(Number.isFinite(i.time)?date(new Date(i.time)):'');
function dateRefs(d){confirmRefs(list('ref').filter(i=>addedOn(i)===d),d+' · 全部图集')}
function confirmRefs(refs,label){
    if(!refs.length){say('这一天没有导入参考图');return}
    const ids=refs.map(x=>x.id);
    async function remove(disk=false){
        if(disk){
            const shared=new Set(items.filter(i=>!ids.includes(i.id)).map(i=>i.original));
            const files=new Set(refs.map(i=>i.original).filter(u=>u?.startsWith('https://albums.invalid/')&&!shared.has(u)));
            for(const url of files)await desktopExtra('trash',url);
        }
        await query('readwrite',s=>{let request;for(const id of ids)request=s.delete(id);return request});
        for(const id of ids)delete positions[id];put('boardPositions',positions);
        if(ids.includes(selectedRef))selectedRef='';await reload();channel?.postMessage(1);modal.close();say('已从参考板移除 '+ids.length+' 张')
    }
    if(prefs.skipDelete){remove().catch(e=>say(e.message));return}
    show('确定删除参考图？','<p>'+esc(label)+'</p><p>从参考板移除 <b>'+ids.length+' 张</b>。</p><label><span><input type="checkbox" id="diskDelete" style="width:auto"> 同时将图集中的磁盘副本移到回收站</span></label><p class="hint">仍被其他参考图使用的副本会保留。</p><label><span><input type="checkbox" id="skipDelete" style="width:auto"> 下次不再询问</span></label><div class="actions">'+action('cancelDialog','取消')+'<button id="deleteRefs" class="danger">确定删除</button></div>');
    $('#deleteRefs').onclick=async e=>{e.target.disabled=true;const skip=$('#skipDelete').checked;try{await remove($('#diskDelete').checked);if(skip){prefs.skipDelete=true;savePrefs()}}catch(err){say(err.message);e.target.disabled=false}};
}
async function pickCheck(d){
    const old=items.find(i=>i.id==='check'+d);
    if(!old){await change({id:'check'+d,type:'check',day:d,emoji:'🎨'});say('今天的绘画记录已打卡');return}
    show('编辑打卡心情','<p>'+esc(d)+'</p><div class="emojiChoices">'+['🎨','😊','🥰','🤩','😌','🥹','😵‍💫','😤','😭','🌱','✨','🐾'].map(x=>'<button data-emoji="'+x+'">'+x+'</button>').join('')+'</div><form id="moodForm"><label>自定义表情<input id="mood" required maxlength="32" value="'+esc(old.emoji||'🎨')+'"></label><button>保存心情</button></form><button id="undoCheck">撤回当天打卡</button>');
    async function save(value){await change({...old,emoji:value});modal.close()}
    modal.querySelectorAll('[data-emoji]').forEach(b=>b.onclick=()=>save(b.dataset.emoji));
    $('#moodForm').onsubmit=e=>{e.preventDefault();const v=$('#mood').value.trim();if(!/\p{Extended_Pictographic}|\p{Regional_Indicator}|\u20E3/u.test(v)){say('请输入一个 emoji');return}save(v)};
    $('#undoCheck').onclick=async()=>{await change(old,true);modal.close()};
}
const tones={'木琴':[523,659,784],'玻璃铃':[988,1319],'水滴':[784,523],'小鸟':[1175,1568,1397],'晚安':[440,330],'单音':[520]};
const baseChime=chime;
chime=function(){
    if(prefs.tone||!audioContext){baseChime();return}
    const notes=tones[prefs.presetTone]||tones['木琴'];notes.forEach((f,n)=>{
        const c=audioContext,t=c.currentTime+n*.135,o=c.createOscillator(),g=c.createGain();o.type='sine';o.frequency.value=f;
        g.gain.setValueAtTime(.001,t);g.gain.exponentialRampToValueAtTime(.066,t+.02);g.gain.exponentialRampToValueAtTime(.001,t+.48);o.connect(g).connect(c.destination);o.start(t);o.stop(t+.5)
    })
};
function soundDialog(){
    show('计时提示音','<label>声音预设<select id="toneChoice">'+Object.keys(tones).map(k=>'<option '+(k===prefs.presetTone?'selected':'')+'>'+k+'</option>').join('')+'</select></label><label>自定义音频（最多 2 MB）<input type="file" accept="audio/*" id="customTone"></label><p id="toneState"></p>'+action('previewTone','试听提示音'));
    const state=()=>$('#toneState').textContent=prefs.tone?'当前使用自定义音频':'当前使用 · '+(prefs.presetTone||'木琴');state();
    $('#toneChoice').onchange=e=>{delete prefs.tone;prefs.presetTone=e.target.value;savePrefs();state();unlockSound();chime()};
    if(prefs.tone)$('#toneChoice').selectedIndex=-1;
    $('#customTone').onchange=async e=>{const f=e.target.files[0];if(!f)return;if(f.size>2000000){say('请选择 2 MB 以内的音频');return}prefs.tone=await dataURL(f);savePrefs();$('#toneChoice').selectedIndex=-1;state()};
}
function startFocusTogether(){if(pomo.mode==='run')return;pomo={mode:'run',phase:'focus',end:Date.now()+prefs.focus*60000,remaining:0,round:pomo.round||0};savePomo()}
function phaseMinutes(){return pomo.phase==='long'?(prefs.longRest||20):pomo.phase==='rest'?prefs.rest:prefs.focus}
updatePomodoro=function(){
    if(pomo.mode!=='run'||Date.now()<pomo.end)return;
    const focused=pomo.phase==='focus';if(focused)pomo.round=(pomo.round||0)+1;
    pomo.phase=focused?(pomo.round%4===0?'long':'rest'):'focus';pomo.mode=focused?'run':'idle';
    pomo.remaining=0;pomo.end=Date.now()+phaseMinutes()*60000;savePomo();chime();
    say(focused?'这段画完啦，起来活动一下 (｡•ᴗ•｡)':'休息结束，可以开始下一轮了');if(view==='time')render()
};
const oldTime=timePage;
timePage=function(){
    oldTime();const root=$('#left');root.querySelector('h1').textContent='绘画工时';
    root.querySelector('.sectionHead').insertAdjacentHTML('beforeend',action('soundDialog',ic('Volume2')+' 声音设置'));
    const draw=root.querySelector('.drawing'),timer=root.querySelector('.tomato'),dial=document.createElement('div');dial.className='workDial';
    const elapsed=$('#elapsed');elapsed.before(dial);dial.append(elapsed);draw.querySelector('h2').textContent='工时计时';
    timer.querySelector('.state').textContent=pomo.phase==='long'?'长休息':pomo.phase==='rest'?'起身休息':'专注';
    timer.querySelector('.twoFields').insertAdjacentHTML('beforebegin','<label class="inlineField">专注 / 短休预设<select id="presetTimes"><option value="">自定义</option>'+[[15,3],[25,5],[45,10],[50,10]].map(([f,r])=>'<option value="'+f+','+r+'" '+(prefs.focus===f&&prefs.rest===r?'selected':'')+'>'+f+' / '+r+' 分钟</option>').join('')+'</select></label>');
    $('#presetTimes').disabled=pomo.mode!=='idle';$('#presetTimes').onchange=e=>{if(!e.target.value)return;[prefs.focus,prefs.rest]=e.target.value.split(',').map(Number);savePrefs();timePage()};
    root.querySelector('.timerGrid>.module:last-child').remove();
    timer.insertAdjacentHTML('beforeend','<small>每 4 轮长休息 20 分钟 · 休息时起来走走。</small>');
    const water=read('water'+now(),0),cups=root.querySelector('.water progress');cups.outerHTML='<div class="cups" aria-label="已喝 '+water+' 杯">'+Array.from({length:Math.min(water,100)},()=>ic('GlassWater')).join('')+(water>100?'＋'+(water-100):water===0?'今天的第一杯，喝完点一下 (´▽｀)':'')+'</div>';
};
function applyLook(){
    const color=/^#[a-f\d]{6}$/i.test(prefs.highlight)?prefs.highlight:'#318361';
    const rgb=[1,3,5].map(i=>parseInt(color.slice(i,i+2),16)/255).map(v=>v<=.04045?v/12.92:((v+.055)/1.055)**2.4);
    document.body.style.setProperty('--key',color);document.body.style.setProperty('--inkOnKey',rgb[0]*.2126+rgb[1]*.7152+rgb[2]*.0722>.179?'#101013':'#fff');
}
const oldSettings=settings;
settings=function(){
    oldSettings();$('#audioPrefs').remove();$('#windowPrefs').insertAdjacentHTML('beforeend','<label>重点颜色<input type="color" value="'+esc(prefs.highlight||'#318361')+'" id="highlight"></label><label>窗口不透明度 <b id="alphaVal">'+(prefs.alpha||100)+'%</b><input type="range" min="35" max="100" value="'+(prefs.alpha||100)+'" id="windowAlpha"></label><label><span><input id="confirmAgain" type="checkbox" style="width:auto" '+(!prefs.skipDelete?'checked':'')+'> 删除参考图前询问</span></label>');
    $('#highlight').oninput=e=>{prefs.highlight=e.target.value;applyLook();savePrefs()};
    $('#windowAlpha').oninput=e=>{prefs.alpha=Number(e.target.value);$('#alphaVal').textContent=prefs.alpha+'%';savePrefs();setWindowAlpha()};
    $('#confirmAgain').onchange=e=>{prefs.skipDelete=!e.target.checked;savePrefs()}
};
function setWindowAlpha(){native?.postMessage({op:'atelierOpacity',id:'atelierOpacity',v:String(prefs.alpha||100)})}
document.addEventListener('click',e=>{
    const cmd=e.target.closest('[data-cmd]')?.dataset.cmd;
    if(cmd==='deleteToday')dateRefs(now());
    if(cmd==='deleteDate'){show('按导入日期删除','<form id="purgeDate"><label>选择日期<input type="date" name="date" required value="'+now()+'"></label><button>查看这天的参考图</button></form>');$('#purgeDate').onsubmit=e=>{e.preventDefault();dateRefs(e.target.elements.date.value)}}
    if(cmd==='cancelDialog')modal.close();if(cmd==='soundDialog')soundDialog();if(cmd==='previewTone'){unlockSound();chime()}
});
const previousLiveRender=render;
render=function(){
    previousLiveRender();applyLook();document.title='活画师 · Live Atelier';
    const nav=$('.tabs'),gift=nav.querySelector('[data-do=gift]'),settingsTab=nav.querySelector('[data-do=settings]');nav.insertBefore(gift,settingsTab);
    for(const [k,n,t] of [['gift','Handshake','无偿'],['links','Globe','网站库'],['settings','Settings','设置'],['time','Timer','工时']])nav.querySelector('[data-do='+k+']').innerHTML=ic(n)+t;
    const back=$('#left [data-a=calendar]');if(back){const head=back.closest('.head');if(head){head.prepend(back);head.classList.add('backHead')}}
    const ck=$('#left [data-do=check]');if(ck){ck.textContent=(items.find(x=>x.id==='check'+(view==='day'?day:now()))?.emoji||'🎨')+' '+(ck.getAttribute('aria-pressed')==='true'?'已打卡 · 换心情':'画画打卡');if(view==='day')$('#left .row')?.prepend(ck)}
    if(view==='calendar'){const checks=new Map(list('check').map(i=>[i.day,i.emoji||'🎨']));document.querySelectorAll('.grid .checked').forEach(b=>{const mark=document.createElement('span');mark.className='dayEmoji';mark.textContent=checks.get(b.dataset.day);b.append(mark)})}
    if(view==='gift')$('#giftLanding small')?.append(' (｡･ω･｡)ﾉ');
    if(db&&!read('liveTourShown',false)){put('liveTourShown',true);tour()}
};
$('.top strong').innerHTML='<img src="icon.png" alt="">活画师';
applyLook();setWindowAlpha();if(db)render();

