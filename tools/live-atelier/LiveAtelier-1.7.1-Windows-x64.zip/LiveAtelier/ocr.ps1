param([string]$Path)
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=New-Object System.Text.UTF8Encoding($false)
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$null=[Windows.Storage.StorageFile,Windows.Storage,ContentType=WindowsRuntime]
$null=[Windows.Graphics.Imaging.BitmapDecoder,Windows.Graphics.Imaging,ContentType=WindowsRuntime]
$null=[Windows.Media.Ocr.OcrEngine,Windows.Foundation,ContentType=WindowsRuntime]
$method=[System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {$_.Name -eq 'AsTask' -and $_.IsGenericMethod -and $_.GetGenericArguments().Count -eq 1 -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'} | Select-Object -First 1
function AwaitOp($op,$type){$task=$method.MakeGenericMethod($type).Invoke($null,@($op));$task.Wait();$task.Result}
$f=AwaitOp ([Windows.Storage.StorageFile]::GetFileFromPathAsync($Path)) ([Windows.Storage.StorageFile])
$s=AwaitOp ($f.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
$d=AwaitOp ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($s)) ([Windows.Graphics.Imaging.BitmapDecoder])
$b=AwaitOp ($d.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
$engine=[Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()
$r=AwaitOp ($engine.RecognizeAsync($b)) ([Windows.Media.Ocr.OcrResult])
$lines=@(foreach($line in $r.Lines){
 $boxes=@($line.Words | ForEach-Object {$_.BoundingRect})
 if(!$boxes.Count){continue}
 $x=($boxes|Measure-Object X -Minimum).Minimum
 $y=($boxes|Measure-Object Y -Minimum).Minimum
 $right=($boxes|ForEach-Object {$_.X+$_.Width}|Measure-Object -Maximum).Maximum
 $bottom=($boxes|ForEach-Object {$_.Y+$_.Height}|Measure-Object -Maximum).Maximum
 @{text=$line.Text;x=$x/$b.PixelWidth;y=$y/$b.PixelHeight;w=($right-$x)/$b.PixelWidth;h=($bottom-$y)/$b.PixelHeight}
})
ConvertTo-Json -InputObject $lines -Compress
